
declare module 'select' {

  export interface SelectItem {
    label: string
    value: string
  }

}