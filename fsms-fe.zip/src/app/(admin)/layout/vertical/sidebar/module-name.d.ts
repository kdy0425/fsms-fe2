declare module 'stylis-plugin-rtl';
